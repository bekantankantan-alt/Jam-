package id.co.jamalam

import android.app.*
import android.appwidget.AppWidgetManager
import android.content.*
import android.graphics.*
import android.os.*
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.*

class ClockUpdateService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            val manager = AppWidgetManager.getInstance(this@ClockUpdateService)
            val ids = manager.getAppWidgetIds(ComponentName(this@ClockUpdateService, ClockWidgetProvider::class.java))
            ids.forEach { updateOne(this@ClockUpdateService, manager, it) }
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val channelId = "clock_live"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Jam berjalan", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId).setContentTitle("Jam Alam Indonesia")
                .setContentText("Pembaruan jam sedang berjalan").setSmallIcon(android.R.drawable.ic_lock_idle_alarm).build()
        else Notification.Builder(this).setContentTitle("Jam Alam Indonesia")
            .setContentText("Pembaruan jam sedang berjalan").setSmallIcon(android.R.drawable.ic_lock_idle_alarm).build()
        startForeground(41, notification)
        handler.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?) = null

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    companion object {
        fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val now = Calendar.getInstance()
            val time = SimpleDateFormat("HH:mm:ss", Locale("id", "ID")).format(now.time)
            val date = SimpleDateFormat("EEEE, dd MMM", Locale("id", "ID")).format(now.time).uppercase(Locale("id", "ID"))
            val views = RemoteViews(context.packageName, R.layout.widget_clock)
            views.setTextViewText(R.id.digital_time, time)
            views.setTextViewText(R.id.date_text, date)
            views.setImageViewBitmap(R.id.analog_clock, drawClock(now))
            val bg = loadBackground(context)
            if (bg != null) views.setImageViewBitmap(R.id.widget_background, bg)
            manager.updateAppWidget(id, views)
        }

        private fun drawClock(c: Calendar): Bitmap {
            val size = 180
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            val center = size / 2f
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = Color.argb(220, 20, 25, 22); p.style = Paint.Style.FILL
            canvas.drawCircle(center, center, 86f, p)
            p.color = Color.rgb(238, 220, 177); p.style = Paint.Style.STROKE; p.strokeWidth = 5f
            canvas.drawCircle(center, center, 83f, p)
            p.style = Paint.Style.FILL
            for (i in 0 until 60) {
                val a = Math.toRadians(i * 6.0 - 90.0)
                val r1 = if (i % 5 == 0) 68f else 74f
                val r2 = 78f
                p.color = if (i % 5 == 0) Color.WHITE else Color.LTGRAY
                p.strokeWidth = if (i % 5 == 0) 3.5f else 1.2f
                canvas.drawLine(center + kotlin.math.cos(a).toFloat()*r1, center + kotlin.math.sin(a).toFloat()*r1,
                    center + kotlin.math.cos(a).toFloat()*r2, center + kotlin.math.sin(a).toFloat()*r2, p)
            }
            val hour = c.get(Calendar.HOUR) + c.get(Calendar.MINUTE)/60f
            val minute = c.get(Calendar.MINUTE) + c.get(Calendar.SECOND)/60f
            val second = c.get(Calendar.SECOND)
            fun hand(angle: Float, length: Float, width: Float, color: Int) {
                val a = Math.toRadians(angle.toDouble() - 90.0)
                p.color = color; p.strokeWidth = width; p.strokeCap = Paint.Cap.ROUND
                canvas.drawLine(center, center, center + kotlin.math.cos(a).toFloat()*length,
                    center + kotlin.math.sin(a).toFloat()*length, p)
            }
            hand(hour*30f, 42f, 7f, Color.WHITE)
            hand(minute*6f, 59f, 4f, Color.WHITE)
            hand(second*6f, 68f, 2f, Color.rgb(255, 90, 65))
            p.color = Color.rgb(255, 210, 130)
            canvas.drawCircle(center, center, 5f, p)
            return bmp
        }

        private fun loadBackground(context: Context): Bitmap? {
            return try {
                val names = context.assets.list("backgrounds")?.filter { it.endsWith(".jpg") }?.sorted() ?: return null
                if (names.isEmpty()) return null
                context.assets.open("backgrounds/" + names[0]).use { BitmapFactory.decodeStream(it) }
            } catch (_: Exception) { null }
        }
    }
}
