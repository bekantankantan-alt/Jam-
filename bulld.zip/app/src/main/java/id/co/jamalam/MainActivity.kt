package id.co.jamalam

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
        }
        box.addView(TextView(this).apply {
            text = "JAM ALAM INDONESIA"
            textSize = 23f
            setTextColor(0xFF234B35.toInt())
        })
        box.addView(TextView(this).apply {
            text = "\nTambahkan widget 4×1 dari daftar widget layar utama.\n\nJam analog dan digital dirancang diperbarui setiap detik saat layanan berjalan. Android/hemat baterai dapat membatasi layanan di latar belakang.\n\nJika widget tidak bergerak, buka aplikasi ini lagi dan izinkan aktivitas latar belakang di pengaturan baterai."
            textSize = 15f
            setTextColor(0xFF222222.toInt())
        })
        val start = Button(this).apply {
            text = "JALANKAN JAM REAL-TIME"
            setOnClickListener {
                val i = Intent(this@MainActivity, ClockUpdateService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                Toast.makeText(this@MainActivity, "Layanan jam dimulai", Toast.LENGTH_SHORT).show()
            }
        }
        box.addView(start)
        setContentView(box)
    }
}
