package id.co.jamalam

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Build

class ClockWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val intent = Intent(context, ClockUpdateService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
        else context.startService(intent)
        ids.forEach { ClockUpdateService.updateOne(context, manager, it) }
    }

    override fun onEnabled(context: Context) {
        val intent = Intent(context, ClockUpdateService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
        else context.startService(intent)
    }

    override fun onDisabled(context: Context) {
        context.stopService(Intent(context, ClockUpdateService::class.java))
    }
}
