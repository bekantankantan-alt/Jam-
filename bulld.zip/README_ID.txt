JAM ALAM INDONESIA — PROJECT ANDROID

Paket ini sudah berisi source project Android, ikon transparan, 10 foto background alam dari ZIP yang dikirim, dan GitHub Actions workflow.

UPLOAD:
1. Ekstrak isi ZIP ini.
2. Upload SEMUA ISI folder JamWidgetIndonesia ke repository GitHub (jangan upload folder luarnya saja).
3. Pastikan .github/workflows/build.yml ikut ter-upload.
4. Buka tab Actions > Build APK > Run workflow.
5. Setelah selesai, buka hasil run dan unduh Artifact "Jam-Widget-Indonesia-debug".

PENTING:
- Workflow memakai Gradle 8.9 dan JDK 17, jadi tidak memerlukan file gradlew.
- Widget 4x1 memakai analog + digital dan background alam pertama.
- Update per detik memakai foreground service dan notifikasi tetap. Android/Realme dapat menghentikan layanan karena penghematan baterai; izinkan aktivitas latar belakang agar lebih stabil.
- Fitur pemilih foto, geser/zoom posisi background, dan pilihan banyak model jam belum dibuat pada versi awal ini. Ini adalah fondasi build yang bisa dikompilasi; jangan anggap fitur tersebut sudah tersedia.
- Ikon launcher PNG transparan tanpa lingkaran yang dibakar ke gambar. Android/launcher dapat menerapkan bentuk mask sendiri pada ikon aplikasi.
