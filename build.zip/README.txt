Paket ikon dan workflow build untuk aplikasi widget jam.

Isi:
- assets/icons/wolf_clock_icon_1024.png: ikon transparan 1024x1024.
- assets/icons/ic_launcher_foreground.png: foreground adaptive icon 432x432.
- .github/workflows/build.yml: workflow GitHub Actions untuk assembleDebug.

PENTING: Paket ini belum berisi source project Android (app/, gradlew, settings.gradle, build.gradle).
Workflow baru dapat menghasilkan APK setelah file project Android lengkap ditambahkan.
